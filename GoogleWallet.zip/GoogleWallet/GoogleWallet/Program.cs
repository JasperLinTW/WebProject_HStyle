﻿internal class Program
{
	private static void Main(string[] args)
	{
		var generic = new DemoGeneric();
        generic.CreateClass("3388000000022304048", "demo5");
        //generic.CreateObject("3388000000022304048", "demo2", "test4");
        generic.CreateJWTNewObjects("3388000000022304048", "demo5", "test13"); 
	}
}